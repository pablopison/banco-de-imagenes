/*Deshabilitar clic derecho mouse página completa*/
$("body").on("contextmenu", function(_e){
    return false;
});
